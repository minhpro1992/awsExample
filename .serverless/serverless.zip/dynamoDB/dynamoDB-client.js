"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDynamoDBClient = void 0;
var AWS = require("aws-sdk");
exports.getDynamoDBClient = (function () {
    var client;
    return function () {
        if (!client) {
            client = new AWS.DynamoDB({});
        }
        return client;
    };
})();
//# sourceMappingURL=dynamoDB-client.js.map