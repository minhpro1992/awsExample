"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dynamoDBService = exports.s3Service = void 0;
exports.s3Service = require("./s3.service");
exports.dynamoDBService = require("./dynamoDB.service");
//# sourceMappingURL=index.js.map