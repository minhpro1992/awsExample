"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.s3Service = void 0;
exports.s3Service = require("./s3.service");
//# sourceMappingURL=index.js.map